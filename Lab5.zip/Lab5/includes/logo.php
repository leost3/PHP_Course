<div id="logo">
	<div style="margin-top:70px" class="whitetitle"><?php echo $student_FirstName; ?></div>
</div>