<div id="topheader">
	<div align="left" class="bodytext">
	<br />
	<strong>Student Name:<?php echo " ".$student_FirstName." ".$student_LastName; ?> </strong><br />
	Course: 420-L04-AS<br />
	Teacher: Salima Hassaine<br />
	Semester: Winter 2017<br />
	</div>
</div>