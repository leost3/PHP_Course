<div id="menu">
<div align="right" class="smallwhitetext" style="padding:9px;">
<a href="#">Home</a> | <a href="#">About Us</a> | <a href="#">Products</a> | <a href="#">Contact Us</a>
</div>
</div>